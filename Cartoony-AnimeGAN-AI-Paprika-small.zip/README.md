# كرتونى (Cartoony) - Android Native Project

تطبيق أندرويد متكامل لتحويل الفيديوهات الواقعية إلى كرتون وأنمي باستخدام **Kotlin** و**Jetpack Compose** وتصميم **Material 3**.

---

## 🎨 المميزات المعمارية والتقنية
- **Kotlin & Jetpack Compose**: واجهات عصرية تفاعلية مبنية بالكامل على Compose.
- **Material 3 Design**: زوايا دائرية 20dp، ظلال ناعمة، ألوان متناسقة، ودعم الوضعين الفاتح والداكن (Light & Dark Themes).
- **RTL Arabic First**: دعم أصلي كامل للغة العربية واتجاه اليمين لليسار مع إمكانية التبديل للإنجليزية.
- **Adaptive Icon (108dp Safe Zone)**:
  - خلفية تدرج بنفسجي إلى برتقالي (`#7C4DFF` إلى `#FF9100`).
  - زر تشغيل مثلث أبيض بحواف دائرية.
  - وجه قط كرتوني مميز (فراء رمادي مزرق، خطم أبيض، عيون زمردية معبرة، حواجب مائلة شقية، أنف وردي، وشوارب).
  - رأس المثلث يتحول لريشة رسم مع قطرة طلاء صفراء (`#FFD600`).
  - فتحات شريط سينمائي على الجانبين.
  - طبقة أحادية اللون (Monochrome Layer) لأيقونات أندرويد 13+ المتكيفة مع المظهر (Themed Icons).
- **MVVM Architecture & StateFlow**:
  - `CartoonyViewModel` لإدارة الحالة عبر `StateFlow<CartoonyUiState>`.
  - واجهة `VideoConverter` المجردة القابلة للتوصيل بنماذج OpenCV / TensorFlow Lite / MediaCodec.
  - محرك `OnDeviceVideoConverter` يعالج الفيديو كاملاً على الجهاز بـ Media3 Transformer وشيدر OpenGL (تحديد ألوان + خطوط + هالفتون + رسم قلم) مع الحفاظ على الصوت والمدة الأصلية، بدون إنترنت أو مفتاح API.
  - `MediaStoreVideoSaver` لحفظ الفيديوهات المنتهية مباشرة إلى مجلد المعرض `Movies/Cartoony` عبر نظام MediaStore المتوافق مع Scoped Storage وAndroid 10 - 15.
- **تغيير الصوت**: اختيار بين الصوت الأصلي أو كرتوني (نغمة أعلى) أو ثقيل (نغمة أقل) عبر `SonicAudioProcessor` بدون تغيير مدة الفيديو.
- **Media3 / ExoPlayer**: مشغل فيديو عالي الأداء مع زر تبديل للمقارنة المباشرة قبل وبعد التحويل (Before & After).

---

## 📂 هيكل المشروع (Project Structure)
```
android/
├── build.gradle.kts                 # إعدادات Gradle العليا
├── settings.gradle.kts              # أسماء الوحدات والمستودعات
├── gradle.properties                # خصائص الذاكرة ودعم AndroidX
├── gradle/
│   └── libs.versions.toml           # كتالوج إصدارات المكتبات (Version Catalog)
└── app/
    ├── build.gradle.kts             # إعدادات وحدة التطبيق وتضمين Jetpack Compose وMedia3
    └── src/
        └── main/
            ├── AndroidManifest.xml   # تصاريح المعرض والشاشة الرئيسية
            ├── java/com/cartoony/app/
            │   ├── MainActivity.kt               # نقطة الانطلاق وإدارة التنقل والـ RTL
            │   ├── model/
            │   │   ├── CartoonStyle.kt          # الأنماط: أنمي، كرتون 2D، كوميكس، إيقاف الحركة، رسم يدوي
            │   │   ├── VideoMetadata.kt         # بيانات الفيديو (الاسم، المدة، الحجم، الأبعاد)
            │   │   └── CartoonyUiState.kt       # كائن الحالة الموحد (StateFlow)
            │   ├── data/
            │   │   ├── converter/
            │   │   │   ├── VideoConverter.kt        # واجهة محرك التحويل
            │   │   │   ├── OnDeviceVideoConverter.kt # محرك التحويل الفعلي على الجهاز
            │   │   │   └── CartoonShaderProgram.kt   # شيدر الأنماط (GLSL)
            │   │   └── storage/
            │   │       └── MediaStoreVideoSaver.kt  # حفظ الفيديو في Movies/Cartoony
            │   ├── viewmodel/
            │   │   └── CartoonyViewModel.kt     # نموذج العرض MVVM
            │   └── ui/
            │       ├── theme/
            │       │   ├── Color.kt             # باليت الألوان والتدرج البنفسجي البرتقالي
            │       │   ├── Theme.kt             # سمة Material3 وزوايا 20dp
            │       │   └── Type.kt              # الخطوط والطباعة
            │       ├── components/
            │       │   ├── CartoonyAppIcon.kt          # رسم الأيقونة التكيفية برمجياً
            │       │   ├── VideoDropZone.kt            # بطاقة رفع الفيديو واختيار الملفات
            │       │   ├── StyleSelectorChips.kt       # شرائح اختيار الستايل الأفقية
            │       │   └── BeforeAfterVideoPlayer.kt   # مشغل ExoPlayer مع زر المقارنة
            │       └── screens/
            │           ├── IntroScreen.kt              # شاشة البداية (الشعار، خطوات العمل، المميزات)
            │           └── MainScreen.kt               # الشاشة الرئيسية بتدفقها الرأسي
            └── res/
                ├── values/
                │   ├── strings.xml           # النصوص باللغة الإنجليزية
                │   ├── colors.xml            # الألوان
                │   └── themes.xml            # سمة النظام
                ├── values-ar/
                │   └── strings.xml           # النصوص الكاملة باللغة العربية
                ├── drawable/
                │   ├── ic_launcher_background.xml
                │   ├── ic_launcher_foreground.xml
                │   └── ic_launcher_monochrome.xml
                └── mipmap-anydpi-v26/
                    ├── ic_launcher.xml
                    └── ic_launcher_round.xml
```

---

## 🚀 كيفية التشغيل في Android Studio
1. افتح **Android Studio** (نسخة Ladybug أو أحدث).
2. اختر **Open** ثم حدد مجلد `android/`.
3. انتظر اكتمال مزامنة Gradle (`Gradle Sync`).
4. اختر جهازاً حقيقياً أو محاكي (Emulator) بنظام Android 8.0 (API 26) فما فوق.
5. اضغط على زر **Run** (أو `Shift + F10`).

## AI conversion

The video conversion engine uses the bundled `AnimeGANv2_Paprika.onnx` neural model through ONNX Runtime on Android. The old `CartoonShaderProgram.kt` color/edge filter is no longer used. Frames are passed through the neural model on-device and then returned to Media3 for video encoding.

The model is bundled under `app/src/main/assets/AnimeGANv2_Paprika.onnx`. Review the upstream AnimeGANv2 license terms before commercial distribution.
