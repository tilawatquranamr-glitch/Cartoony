package com.cartoony.app.data.converter

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.cartoony.app.data.config.CartoonyConfig
import com.cartoony.app.model.CartoonStyle
import com.cartoony.app.model.VoiceStyle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Real on-device converter: decodes video frames through Media3, runs AnimeGANv2
 * neural inference on each frame, and re-encodes the result with the selected audio effect.
 * No upload, no API key, and no cloud service are required.
 */
@OptIn(UnstableApi::class)
class OnDeviceVideoConverter(private val context: Context) : VideoConverter {

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var activeTransformer: Transformer? = null

    override suspend fun convert(
        inputUri: Uri,
        style: CartoonStyle,
        voice: VoiceStyle,
        onProgress: (progress: Float, stageDescription: String) -> Unit
    ): Result<Uri> {
        val outDir = File(context.cacheDir, "converted_videos").apply { mkdirs() }
        val outFile = File(outDir, "cartoony_${style.id}_${System.currentTimeMillis()}.mp4")

        return try {
            onProgress(0.02f, "تجهيز الفيديو…")
            val height = withContext(Dispatchers.IO) { readDisplayHeight(inputUri) }

            withContext(Dispatchers.Main) {
                runTransformer(inputUri, style, voice, height, outFile, onProgress)
            }

            if (!outFile.exists() || outFile.length() == 0L) {
                throw VideoConversionException(
                    errorCode = "EMPTY_OUTPUT",
                    localizedMessageAr = "لم يتم إنتاج فيديو صالح، يرجى المحاولة مرة أخرى"
                )
            }
            onProgress(1f, "اكتمل تحويل الفيديو بنجاح!")
            Result.success(Uri.fromFile(outFile))
        } catch (e: CancellationException) {
            outFile.delete()
            throw e
        } catch (e: VideoConversionException) {
            outFile.delete()
            Result.failure(e)
        } catch (e: Exception) {
            outFile.delete()
            Result.failure(
                VideoConversionException(
                    errorCode = "CONVERSION_FAILED",
                    localizedMessageAr = "تعذر تحويل هذا الفيديو، جرّب فيديو آخر أو أعد المحاولة",
                    cause = e
                )
            )
        }
    }

    override fun cancel() {
        mainHandler.post { activeTransformer?.cancel() }
    }

    private suspend fun runTransformer(
        inputUri: Uri,
        style: CartoonStyle,
        voice: VoiceStyle,
        displayHeight: Int,
        outFile: File,
        onProgress: (Float, String) -> Unit
    ) = coroutineScope {
        val videoEffects = buildList<Effect> {
            if (style == CartoonStyle.STOP_MOTION) {
                add(FrameDropEffect.createDefaultFrameDropEffect(10f))
            }
            if (displayHeight > MAX_OUTPUT_HEIGHT) {
                add(Presentation.createForHeight(MAX_OUTPUT_HEIGHT))
            }
            // Real AI stylization. AnimeGANv2 is an ONNX neural model, not a GLSL color filter.
            add(AnimeGanGlEffect(
                context = context,
                modelAsset = when (style) {
                    CartoonStyle.ANIME_SHINKAI -> AnimeGanGlEffect.MODEL_SHINKAI
                    CartoonStyle.ANIME_PAPRIKA -> AnimeGanGlEffect.MODEL_PAPRIKA
                    else -> AnimeGanGlEffect.MODEL_HAYAO
                }
            ))
        }

        // Pitch shift only (speed stays 1.0), so audio length still matches the video.
        val audioProcessors = buildList<AudioProcessor> {
            if (voice != VoiceStyle.ORIGINAL) {
                add(SonicAudioProcessor().apply { setPitch(voice.pitch) })
            }
        }

        val item = EditedMediaItem.Builder(MediaItem.fromUri(inputUri))
            .setEffects(Effects(audioProcessors, videoEffects))
            .build()

        var transformer: Transformer? = null

        val progressJob = launch {
            val holder = ProgressHolder()
            while (isActive) {
                val t = transformer
                if (t != null && t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(
                        0.05f + holder.progress / 100f * 0.93f,
                        "تحويل الفيديو بالذكاء الاصطناعي… ${holder.progress}%"
                    )
                }
                delay(300)
            }
        }

        try {
            suspendCancellableCoroutine<Unit> { cont ->
                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (cont.isActive) cont.resumeWithException(mapError(exportException))
                    }
                }
                val t = Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .addListener(listener)
                    .build()
                transformer = t
                activeTransformer = t
                cont.invokeOnCancellation { mainHandler.post { t.cancel() } }
                t.start(item, outFile.absolutePath)
            }
        } finally {
            progressJob.cancel()
            activeTransformer = null
        }
    }

    private fun mapError(e: ExportException): VideoConversionException {
        val message = when (e.errorCode) {
            ExportException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            ExportException.ERROR_CODE_DECODER_INIT_FAILED ->
                "صيغة هذا الفيديو غير مدعومة على جهازك، جرّب فيديو بصيغة MP4 عادية"
            ExportException.ERROR_CODE_IO_FILE_NOT_FOUND,
            ExportException.ERROR_CODE_IO_NO_PERMISSION ->
                "تعذر فتح الفيديو، تأكد من صلاحية الوصول للملف"
            else -> "تعذر تحويل هذا الفيديو، جرّب فيديو آخر أو أعد المحاولة"
        }
        return VideoConversionException("EXPORT_${e.errorCode}", message, cause = e)
    }

    /** Height as displayed (after rotation) so we only downscale big videos, never upscale. */
    private fun readDisplayHeight(uri: Uri): Int {
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(context, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (rot == 90 || rot == 270) w else h
        } catch (_: Exception) {
            0
        }
    }


    private companion object {
        const val MAX_OUTPUT_HEIGHT = CartoonyConfig.MAX_OUTPUT_HEIGHT
    }
}
