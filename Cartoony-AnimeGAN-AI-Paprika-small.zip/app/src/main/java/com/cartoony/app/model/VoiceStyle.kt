package com.cartoony.app.model

/**
 * Voice treatment applied to the video's original audio.
 * Pitch is changed without changing speed, so the video keeps its exact duration.
 */
enum class VoiceStyle(
    val id: String,
    val arTitle: String,
    val enTitle: String,
    val pitch: Float
) {
    ORIGINAL("original", "الصوت الأصلي", "Original", 1.0f),
    CARTOON("cartoon_voice", "صوت كرتوني", "Cartoon voice", 1.45f),
    DEEP("deep_voice", "صوت ثقيل", "Deep voice", 0.72f);

    companion object {
        fun default(): VoiceStyle = CARTOON
    }
}
