package com.cartoony.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Brand Palette
val CartoonyPurple = Color(0xFF7C4DFF)
val CartoonyPurpleDark = Color(0xFF5E35B1)
val CartoonyPurpleContainer = Color(0xFFEDE7F6)

val CartoonyOrange = Color(0xFFFF9100)
val CartoonyOrangeDark = Color(0xFFEF6C00)
val CartoonyYellow = Color(0xFFFFD600)

val CartoonyGradient = Brush.linearGradient(
    colors = listOf(CartoonyPurple, CartoonyOrange)
)

val CartoonyGradientHorizontal = Brush.horizontalGradient(
    colors = listOf(CartoonyPurple, CartoonyOrange)
)

// Light Theme
val LightPrimary = Color(0xFF6750A4)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFEADDFF)
val LightOnPrimaryContainer = Color(0xFF21005D)
val LightSecondary = Color(0xFF625B71)
val LightBackground = Color(0xFFFAF8FD)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0ECF4)
val LightOnSurface = Color(0xFF1D1B20)
val LightOnSurfaceVariant = Color(0xFF49454F)

// Dark Theme
val DarkPrimary = Color(0xFFD0BCFF)
val DarkOnPrimary = Color(0xFF381E72)
val DarkPrimaryContainer = Color(0xFF4F378B)
val DarkOnPrimaryContainer = Color(0xFFEADDFF)
val DarkSecondary = Color(0xFFCCC2DC)
val DarkBackground = Color(0xFF0F0E17)
val DarkSurface = Color(0xFF1B1926)
val DarkSurfaceVariant = Color(0xFF2B283A)
val DarkOnSurface = Color(0xFFE6E0E9)
val DarkOnSurfaceVariant = Color(0xFFCAC4D0)
