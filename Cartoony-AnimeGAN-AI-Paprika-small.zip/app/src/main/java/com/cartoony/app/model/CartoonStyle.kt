package com.cartoony.app.model

import androidx.annotation.StringRes
import com.cartoony.app.R

/**
 * Represents the artistic transformation styles supported by Cartoony.
 */
enum class CartoonStyle(
    val id: String,
    @StringRes val titleResId: Int,
    val enTitle: String,
    val arTitle: String,
    val descriptionAr: String,
    val isIntroFeatured: Boolean
) {
    ANIME(
        id = "anime",
        titleResId = R.string.style_anime,
        enTitle = "Anime",
        arTitle = "أنمي",
        descriptionAr = "ألوان يابانية نابضة بالحياة مع إضاءة سينمائية وتدرجات مائية ناعمة",
        isIntroFeatured = true
    ),
    ANIME_SHINKAI(
        id = "anime_shinkai",
        titleResId = R.string.style_anime_shinkai,
        enTitle = "Anime Shinkai",
        arTitle = "أنمي شينكاي",
        descriptionAr = "أسلوب أنمي سينمائي مستوحى من نموذج AnimeGANv2 Shinkai",
        isIntroFeatured = false
    ),
    ANIME_PAPRIKA(
        id = "anime_paprika",
        titleResId = R.string.style_anime_paprika,
        enTitle = "Anime Paprika",
        arTitle = "أنمي بابريكا",
        descriptionAr = "أسلوب أنمي ملون مستوحى من نموذج AnimeGANv2 Paprika",
        isIntroFeatured = false
    ),
    CARTOON_2D(
        id = "cartoon",
        titleResId = R.string.style_cartoon,
        enTitle = "2D Cartoon",
        arTitle = "كرتون 2D",
        descriptionAr = "خطوط خارجية عريضة بارزة مع ألوان مسطحة مبهجة على طريقة الرسوم المتحركة الكلاسيكية",
        isIntroFeatured = true
    ),
    COMIC(
        id = "comic",
        titleResId = R.string.style_comic,
        enTitle = "Comic",
        arTitle = "كوميكس",
        descriptionAr = "أسلوب القصص المصورة والبوب آرت بنقاط هالفتون حادة وحبر أسود ديناميكي",
        isIntroFeatured = false
    ),
    STOP_MOTION(
        id = "stopmotion",
        titleResId = R.string.style_stopmotion,
        enTitle = "Stop Motion",
        arTitle = "إيقاف الحركة",
        descriptionAr = "ملمس الطين والصلصال اليدوي الملموس مع حركة كلاسيكية متقطعة وجذابة",
        isIntroFeatured = true
    ),
    SKETCH(
        id = "sketch",
        titleResId = R.string.style_sketch,
        enTitle = "Sketch",
        arTitle = "رسم يدوي",
        descriptionAr = "تخطيط يدوي فني بأقلام الفحم والرصاص مع تفاصيل خطية دقيقة",
        isIntroFeatured = false
    );

    companion object {
        fun default(): CartoonStyle = ANIME
    }
}
