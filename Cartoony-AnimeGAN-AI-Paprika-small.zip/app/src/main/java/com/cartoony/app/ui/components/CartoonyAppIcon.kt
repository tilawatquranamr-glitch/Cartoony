package com.cartoony.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.cartoony.app.ui.theme.CartoonyGradient
import com.cartoony.app.ui.theme.CartoonyOrange
import com.cartoony.app.ui.theme.CartoonyPurple
import com.cartoony.app.ui.theme.CartoonyYellow

/**
 * Renders the Cartoony Adaptive Icon in Compose with the purple-to-orange gradient,
 * play triangle, cat face, paintbrush tip with yellow drop, and film perforations.
 */
@Composable
fun CartoonyAppIcon(
    size: Dp = 100.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .shadow(elevation = 12.dp, shape = RoundedCornerShape(26.dp), spotColor = CartoonyPurple.copy(alpha = 0.4f))
            .clip(RoundedCornerShape(26.dp))
            .background(CartoonyGradient),
        contentAlignment = Alignment.Center
    ) {
        // Film perforations left
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = 6.dp)
                .size(width = 4.dp, height = size * 0.65f)
                .background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
        )
        // Film perforations right
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .offset(x = (-6).dp)
                .size(width = 4.dp, height = size * 0.65f)
                .background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
        )

        // Center white play button container with cat face & paintbrush
        Box(
            modifier = Modifier
                .size(size * 0.62f)
                .background(Color.White, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Stylized Cat Avatar representation
            Box(
                modifier = Modifier
                    .size(size * 0.45f)
                    .clip(CircleShape)
                    .background(Color(0xFF78909C)),
                contentAlignment = Alignment.Center
            ) {
                // Cat ears
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = 4.dp, y = (-2).dp)
                        .size(size * 0.12f)
                        .background(Color(0xFF546E7A), RoundedCornerShape(2.dp))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-4).dp, y = (-2).dp)
                        .size(size * 0.12f)
                        .background(Color(0xFF546E7A), RoundedCornerShape(2.dp))
                )

                // White muzzle
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = (-4).dp)
                        .size(width = size * 0.26f, height = size * 0.16f)
                        .background(Color(0xFFECEFF1), RoundedCornerShape(8.dp))
                )

                // Emerald eyes
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .offset(x = 10.dp, y = (-3).dp)
                        .size(size * 0.09f)
                        .background(Color(0xFF00E676), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .offset(x = (-10).dp, y = (-3).dp)
                        .size(size * 0.09f)
                        .background(Color(0xFF00E676), CircleShape)
                )

                // Cute pink nose
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 2.dp)
                        .size(width = 6.dp, height = 4.dp)
                        .background(Color(0xFFFF4081), RoundedCornerShape(2.dp))
                )
            }

            // Yellow paint drop accent on the paintbrush tip
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 4.dp, y = 4.dp)
                    .size(size * 0.15f)
                    .shadow(4.dp, CircleShape)
                    .background(CartoonyYellow, CircleShape)
            )
        }
    }
}
