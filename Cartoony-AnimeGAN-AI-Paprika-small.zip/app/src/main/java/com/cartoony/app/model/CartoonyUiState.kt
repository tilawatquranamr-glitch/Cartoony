package com.cartoony.app.model

import android.net.Uri

/**
 * UI State for Cartoony App following MVI / MVVM StateFlow patterns.
 * Supports multi-segment video conversion with up to 60s clips,
 * provider 10s chunking, single-segment retry, and detailed Arabic statuses.
 */
data class CartoonyUiState(
    val selectedVideo: VideoMetadata? = null,
    val selectedStyle: CartoonStyle = CartoonStyle.ANIME,
    val selectedVoice: VoiceStyle = VoiceStyle.default(),
    val isProcessing: Boolean = false,
    val progress: Float = 0f, // 0.0f to 1.0f
    val stageMessage: String = "",
    val convertedVideoUri: Uri? = null,
    val convertedFileName: String? = null,
    val isShowingOriginal: Boolean = false,
    val splitPosition: Float = 0.5f,
    val errorMessage: String? = null,
    val errorCode: String? = null,
    val canRetry: Boolean = false,
    val failedSegmentIndex: Int? = null, // Set if a specific segment failed
    val isSavedToGallery: Boolean = false,
    val savedFilePath: String? = null,
    val isArabicLocale: Boolean = true,
    
    // Multi-segment metrics
    val totalSegments: Int = 1,
    val currentSegmentIndex: Int = 1,
    val isDurationExceeded: Boolean = false,
    val durationExceededMessageAr: String? = null,
    val segmentNoteAr: String? = null,
    val activeStylePrompt: String? = null
) {
    val canConvert: Boolean
        get() = selectedVideo != null && !isProcessing && !isDurationExceeded

    val hasConvertedResult: Boolean
        get() = convertedVideoUri != null
}
