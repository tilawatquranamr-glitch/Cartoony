package com.cartoony.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.cartoony.app.ui.screens.IntroScreen
import com.cartoony.app.ui.screens.MainScreen
import com.cartoony.app.ui.theme.CartoonyTheme
import com.cartoony.app.viewmodel.CartoonyViewModel

/**
 * Main Activity host for Cartoony Android application.
 * Manages full RTL Arabic layout direction, navigation flow, and ViewModel binding.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: CartoonyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val uiState by viewModel.uiState.collectAsState()
            
            // RTL Arabic support
            val layoutDirection = if (uiState.isArabicLocale) {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                CartoonyTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        CartoonyAppNavigation(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

/**
 * Navigation controller switching between Intro Screen and Main Screen with smooth transitions.
 */
@Composable
fun CartoonyAppNavigation(viewModel: CartoonyViewModel) {
    var currentScreen by remember { mutableStateOf("intro") }
    val uiState by viewModel.uiState.collectAsState()

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            if (targetState == "main") {
                slideInHorizontally { width -> width } togetherWith slideOutHorizontally { width -> -width }
            } else {
                slideInHorizontally { width -> -width } togetherWith slideOutHorizontally { width -> width }
            }
        },
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            "intro" -> {
                IntroScreen(
                    onStartNowClick = { currentScreen = "main" }
                )
            }
            "main" -> {
                MainScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onBackToIntro = { currentScreen = "intro" }
                )
            }
        }
    }
}
