package com.cartoony.app.viewmodel

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cartoony.app.data.config.CartoonyConfig
import com.cartoony.app.data.converter.OnDeviceVideoConverter
import com.cartoony.app.data.converter.VideoConversionException
import com.cartoony.app.data.converter.VideoConverter
import com.cartoony.app.data.storage.MediaStoreVideoSaver
import com.cartoony.app.model.CartoonStyle
import com.cartoony.app.model.CartoonyUiState
import com.cartoony.app.model.VideoMetadata
import com.cartoony.app.model.VoiceStyle
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel governing state for Cartoony app according to MVVM architecture with StateFlow.
 * Converts the full video on the device (no upload, no API key).
 */
class CartoonyViewModel(
    application: Application,
    private val videoConverter: VideoConverter = OnDeviceVideoConverter(application),
    private val mediaStoreVideoSaver: MediaStoreVideoSaver = MediaStoreVideoSaver(application)
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(CartoonyUiState())
    val uiState: StateFlow<CartoonyUiState> = _uiState.asStateFlow()

    private var conversionJob: Job? = null

    /**
     * Handles user picking a video from the Photo Picker.
     */
    fun onVideoPicked(uri: Uri) {
        viewModelScope.launch {
            val metadata = extractMetadata(uri)
            val durationMs = metadata.durationMs
            val maxAllowedMs = CartoonyConfig.MAX_ALLOWED_VIDEO_DURATION_MS
            val isExceeded = durationMs > maxAllowedMs
            val durationSec = Math.round(durationMs / 1000.0)
            val maxMin = maxAllowedMs / 60_000

            val exceededMessage = if (isExceeded) {
                "الحد الأقصى المسموح به لطول الفيديو هو $maxMin دقائق. مدة الفيديو الحالي: $durationSec ثانية. يرجى اختيار مقطع أقصر."
            } else null

            val note = if (!isExceeded && durationMs > 60_000L) {
                "الفيديو الطويل يستغرق وقتاً أطول في التحويل. أبقِ التطبيق مفتوحاً حتى ينتهي."
            } else null

            _uiState.update { current ->
                current.copy(
                    selectedVideo = metadata,
                    convertedVideoUri = null,
                    convertedFileName = null,
                    errorMessage = null,
                    errorCode = null,
                    progress = 0f,
                    isSavedToGallery = false,
                    savedFilePath = null,
                    totalSegments = 1,
                    currentSegmentIndex = 1,
                    isDurationExceeded = isExceeded,
                    durationExceededMessageAr = exceededMessage,
                    segmentNoteAr = note,
                    activeStylePrompt = null
                )
            }
        }
    }

    /**
     * Selects a cartoon artistic style and updates the associated AI prompt.
     */
    fun onStyleSelected(style: CartoonStyle) {
        _uiState.update {
            it.copy(
                selectedStyle = style
            )
        }
    }

    fun onVoiceSelected(voice: VoiceStyle) {
        _uiState.update { it.copy(selectedVoice = voice) }
    }

    /**
     * Starts converting the selected video to the chosen style.
     */
    fun startConversion() {
        val currentState = _uiState.value
        val video = currentState.selectedVideo ?: return
        val style = currentState.selectedStyle
        val voice = currentState.selectedVoice

        if (currentState.isDurationExceeded) {
            _uiState.update {
                it.copy(
                    errorMessage = currentState.durationExceededMessageAr ?: "الفيديو أطول من الحد المسموح",
                    canRetry = false
                )
            }
            return
        }

        conversionJob?.cancel()
        _uiState.update {
            it.copy(
                isProcessing = true,
                progress = 0.05f,
                stageMessage = "جارٍ تجهيز الفيديو للتحويل…",
                errorMessage = null,
                errorCode = null,
                canRetry = false,
                failedSegmentIndex = null
            )
        }

        conversionJob = viewModelScope.launch {
            val result = videoConverter.convert(
                inputUri = video.uri,
                style = style,
                voice = voice,
                onProgress = { progress, stage ->
                    _uiState.update {
                        it.copy(
                            progress = progress,
                            stageMessage = stage
                        )
                    }
                }
            )

            result.fold(
                onSuccess = { convertedUri ->
                    val baseName = video.name.substringBeforeLast(".")
                    val fileName = "${baseName}_${style.id}.mp4"
                    _uiState.update {
                        it.copy(
                            isProcessing = false,
                            progress = 1.0f,
                            convertedVideoUri = convertedUri,
                            convertedFileName = fileName,
                            errorMessage = null,
                            errorCode = null,
                            failedSegmentIndex = null
                        )
                    }
                },
                onFailure = { error ->
                    if (error !is kotlinx.coroutines.CancellationException) {
                        val message = when (error) {
                            is VideoConversionException -> error.localizedMessageAr
                            else -> "حدث خطأ أثناء تحويل الفيديو، اضغط إعادة المحاولة"
                        }
                        val code = (error as? VideoConversionException)?.errorCode ?: "CONVERSION_FAILED"

                        _uiState.update {
                            it.copy(
                                isProcessing = false,
                                errorMessage = message,
                                errorCode = code,
                                canRetry = (error as? VideoConversionException)?.canRetry ?: true,
                                failedSegmentIndex = null
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                isProcessing = false,
                                progress = 0f,
                                stageMessage = "تم إلغاء عملية التحويل"
                            )
                        }
                    }
                }
            )
        }
    }

    fun cancelConversion() {
        videoConverter.cancel()
        conversionJob?.cancel()
        _uiState.update {
            it.copy(
                isProcessing = false,
                progress = 0f,
                stageMessage = "تم إلغاء التحويل"
            )
        }
    }

    fun retryConversion() {
        _uiState.update { it.copy(errorMessage = null, errorCode = null) }
        startConversion()
    }

    fun toggleBeforeAfter() {
        _uiState.update { it.copy(isShowingOriginal = !it.isShowingOriginal) }
    }

    fun setSplitPosition(position: Float) {
        _uiState.update { it.copy(splitPosition = position.coerceIn(0f, 1f)) }
    }

    fun saveToGallery(onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        val state = _uiState.value
        val sourceUri = state.convertedVideoUri ?: return
        val originalName = state.selectedVideo?.name ?: "video"
        val styleName = state.selectedStyle.id

        viewModelScope.launch {
            val result = mediaStoreVideoSaver.saveToGallery(
                sourceUri = sourceUri,
                originalName = originalName,
                styleName = styleName
            )

            result.fold(
                onSuccess = { _ ->
                    val finalFileName = "${originalName.substringBeforeLast(".")}_${styleName}.mp4"
                    _uiState.update {
                        it.copy(
                            isSavedToGallery = true,
                            savedFilePath = "Movies/Cartoony/$finalFileName"
                        )
                    }
                    onSuccess(finalFileName)
                },
                onFailure = { error ->
                    onError(error.localizedMessage ?: "فشل في حفظ الفيديو في المعرض")
                }
            )
        }
    }

    fun toggleLocale() {
        _uiState.update { it.copy(isArabicLocale = !it.isArabicLocale) }
    }

    private fun extractMetadata(uri: Uri): VideoMetadata {
        val context = getApplication<Application>()
        var name = "video_${System.currentTimeMillis()}.mp4"
        var sizeBytes = 0L

        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex != -1) {
                    name = cursor.getString(nameIndex) ?: name
                }
                if (sizeIndex != -1) {
                    sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        }

        var durationMs = 0L
        var width = 0
        var height = 0

        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 0L

            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            width = widthStr?.toIntOrNull() ?: 0
            height = heightStr?.toIntOrNull() ?: 0

            retriever.release()
        } catch (_: Exception) {
            durationMs = 0L
        }

        return VideoMetadata(
            uri = uri,
            name = name,
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            width = width,
            height = height
        )
    }
}
