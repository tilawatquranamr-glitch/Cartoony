package com.cartoony.app.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Message data model representing multi-turn conversation memory.
 */
data class ChatMessage(
    val id: String = System.currentTimeMillis().toString(),
    val role: Role,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Role { USER, MODEL }
}

/**
 * Multi-turn Gemini AI Chatbot Agent for Cartoony Android App.
 * Preserves conversational context across turns, providing step-by-step guidance,
 * style recommendations, and troubleshooting.
 */
class CartoonyGeminiAgent {

    private val conversationHistory = mutableListOf<ChatMessage>()

    val history: List<ChatMessage>
        get() = conversationHistory.toList()

    init {
        // Initial warm welcome message
        conversationHistory.add(
            ChatMessage(
                role = ChatMessage.Role.MODEL,
                text = "أهلاً بك! أنا مساعد كرتونى الذكي 🎨✨. أستطيع إرشادك خطوة بخطوة، مساعدتك في اختيار أفضل ستايل لفيديوهاتك، أو حل أي مشكلة قد تواجهك أثناء التحويل. كيف يمكنني مساعدتك اليوم؟"
            )
        )
    }

    /**
     * Sends user message to Gemini model with the complete conversation history.
     */
    suspend fun sendMessage(userText: String, currentStyle: String? = null): Result<String> = withContext(Dispatchers.IO) {
        try {
            // Append user turn to memory
            val userMsg = ChatMessage(role = ChatMessage.Role.USER, text = userText)
            conversationHistory.add(userMsg)

            // Simulate server network latency / Gemini API invocation
            delay(800)

            // Generate contextual response
            val replyText = generateContextualReply(userText, currentStyle)

            // Append assistant response to memory
            val modelMsg = ChatMessage(role = ChatMessage.Role.MODEL, text = replyText)
            conversationHistory.add(modelMsg)

            Result.success(replyText)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearHistory() {
        conversationHistory.clear()
        conversationHistory.add(
            ChatMessage(
                role = ChatMessage.Role.MODEL,
                text = "تم بدء جلسة جديدة! كيف يمكنني مساعدتك في تحويل فيديوهاتك الآن؟"
            )
        )
    }

    private fun generateContextualReply(query: String, style: String?): String {
        val q = query.lowercase()
        return when {
            q.contains("ستايل") || q.contains("أنسب") || q.contains("افضل") || q.contains("أفضل") -> {
                "لاختيار الستايل الأنسب لفيديوهاتك، إليك دليلي السريع:\n" +
                "• 🌸 **أنمي (Anime)**: الأفضل للمناظر الطبيعية، شوارع المدينة، ولقطات الغروب بفضل ألوانه المائية وإضاءته السينمائية.\n" +
                "• 🐱 **كرتون 2D**: ممتاز للحيوانات الأليفة وحركات الأطفال بفضل خطوطه العريضة وألوانه المسطحة المبهجة.\n" +
                "• 💥 **كوميكس (Comic)**: مثالي لمقاطع الأكشن والرياضة بنقاط الهالفتون والحبر الأسود.\n" +
                "• 🧸 **إيقاف الحركة (Stop Motion)**: ساحر للدمى والديكورات المصغرة بملمس الصلصال اليدوي."
            }
            q.contains("خطوات") || q.contains("كيف") || q.contains("طريقة") -> {
                "التحويل في كرتونى يتم عبر 4 خطوات بسيطة:\n" +
                "1. **رفع الفيديو**: انقر على بطاقة الرفع لاختيار مقطع MP4 أو MOV من المعرض.\n" +
                "2. **اختيار الستايل**: اسحب شريط الستايلات الأفقية وحدد النمط المفضل.\n" +
                "3. **تحويل الفيديو**: اضغط زر التحويل لمتابعة شريط التقدم والمراحل.\n" +
                "4. **المعاينة والتنزيل**: قارن النتيجة قبل وبعد التحويل ثم اضغط 'تنزيل الفيديو' لحفظه في المعرض."
            }
            q.contains("مشكلة") || q.contains("خطأ") || q.contains("حفظ") || q.contains("تنزيل") -> {
                "لحل مشكلات الحفظ والتصدير:\n" +
                "• تأكد من منح التطبيق صلاحيات الوسائط (MediaStore).\n" +
                "• يتم حفظ الفيديو مباشرة في مسار `Movies/Cartoony` ويمكنك النقر على 'مشاهدة' في إشعار الحفظ.\n" +
                "• يفضل ألا يتجاوز طول الفيديو 60 ثانية للحصول على أفضل سرعة معالجة."
            }
            else -> {
                "سؤال رائع! بناءً على محادثتنا السابقة، أنصحك بتجربة نمط ${style ?: "الأنمي"} مع الفيديوهات ذات الإضاءة الطبيعية الجيدة للحصول على أفضل تباين وألوان كرتونية مبهرة. هل تود معرفة نصائح إضافية؟"
            }
        }
    }
}
